#include <iostream>

using namespace std;





void LabInfo(){

cout<< "Michael O'Connor\n";
cout<< "Lab 4";
}

class labInfo{

public:
    string name;
    string labId;
    string day;
    string month;
    int year;

};





