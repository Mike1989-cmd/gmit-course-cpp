#include <iostream>

using namespace std;

class Point{
   //public:
    Point(){cout << "Point class constructed";}
};
int main()
{
    Point t1;
    return 0;
}
